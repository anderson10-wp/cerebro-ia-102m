import inspect
import time
from typing import Any, Callable, Dict, Generator, Iterator, List, Optional

import docker
import requests
from rich.console import Console

from lightning_sdk.api.utils import _get_registry_url, cached_lightning_client
from lightning_sdk.lightning_cloud.env import LIGHTNING_CLOUD_URL
from lightning_sdk.lightning_cloud.openapi.models import V1DeleteLitRepositoryResponse
from lightning_sdk.teamspace import Teamspace


class LCRAuthFailedError(Exception):
    """Raised when authentication with the Lightning Container Registry fails."""

    def __init__(self) -> None:
        super().__init__("Failed to authenticate with Lightning Container Registry. Please try again.")


class DockerPushError(Exception):
    """Raised when a Docker image push operation fails."""


class DockerNotRunningError(Exception):
    """Raised when the Docker daemon is unreachable."""

    def __init__(self, message: str = "Failed to connect to Docker") -> None:
        self.message = message
        super().__init__(self.message)

    def print_help(self) -> None:
        console = Console()
        console.print("[bold red]Docker Error: Failed to connect to Docker. Is it running?[/bold red]")
        console.print("[yellow]Troubleshooting:[/yellow]")
        console.print("1. Check if Docker daemon is running")
        console.print("2. Verify your user has proper permissions")
        console.print("3. Try restarting Docker service")
        console.print("4. Read more here: https://docs.docker.com/engine/daemon/start/")


def retry_on_lcr_auth_failure(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that re-authenticates once and retries the wrapped method on ``LCRAuthFailedError``.

    Args:
        func: The method to wrap; must be a bound method of ``LitContainerApi``.

    Returns:
        Callable: The wrapped function that retries after re-authentication.
    """

    def generator_wrapper(self: "LitContainerApi", *args: Any, **kwargs: Any) -> Generator[Any, None, None]:
        try:
            gen = func(self, *args, **kwargs)
            yield from gen
        except LCRAuthFailedError:
            self.authenticate(reauth=True)
            gen = func(self, *args, **kwargs)
            yield from gen
        return

    def wrapper(self: "LitContainerApi", *args: Any, **kwargs: Any) -> Any:
        try:
            return func(self, *args, **kwargs)
        except LCRAuthFailedError:
            self.authenticate(reauth=True)
            return func(self, *args, **kwargs)

    if inspect.isgeneratorfunction(func):
        return generator_wrapper

    return wrapper


class LitContainerApi:
    """Internal API client for Lightning Container Registry (LitCR) operations."""

    def __init__(self) -> None:
        self._client = cached_lightning_client()

        try:
            self._docker_client = docker.from_env()
            self._docker_client.ping()
            self._docker_auth_config: Dict[str, str] = {}
        except docker.errors.DockerException:
            raise DockerNotRunningError() from None

    def authenticate(self, reauth: bool = False) -> bool:
        """Authenticate the Docker client against the Lightning Container Registry.

        Args:
            reauth: Force re-authentication even if a valid session already exists.

        Returns:
            ``True`` if authentication succeeded, ``False`` otherwise.
        """
        resp = None
        try:
            authed_user = self._client.auth_service_get_user()
            username = authed_user.username
            api_key = authed_user.api_key
            registry = _get_registry_url()
            resp = self._docker_client.login(username, password=api_key, registry=registry, reauth=reauth)

            if (
                resp.get("username", None) == username
                and resp.get("password", None) == api_key
                and resp.get("serveraddress", None) == registry
            ):
                self._docker_auth_config = {"username": username, "password": api_key}
                return True

            # This is a new 200 response auth attempt from the client.
            if "Status" in resp and resp["Status"] == "Login Succeeded":
                self._docker_auth_config = {"username": username, "password": api_key}
                return True

            return False
        except Exception as e:
            print(f"Authentication error: {e} resp: {resp}")
            return False

    def list_containers(self, project_id: str, cloud_account: Optional[str] = None) -> List:
        """Lists containers of the project ID.

        :param project_id: The non-human readable project ID used internally to identify projects.
        :param cloud_account: The cluster ID of the cloud account. If None, will use the default cluster.
        :return:

        Args:
            project_id: The non-human readable project ID used internally to identify projects.
            cloud_account: The cluster ID of the cloud account; uses the default cluster if ``None``.

        Returns:
            List: The list of container repositories in the project registry.
        """
        if cloud_account is None:
            project = self._client.lit_registry_service_get_lit_project_registry(project_id)
        else:
            project = self._client.lit_registry_service_get_lit_project_registry(project_id, cluster_id=cloud_account)

        return project.repositories

    def delete_container(self, project_id: str, container: str) -> V1DeleteLitRepositoryResponse:
        """Deletes the container from LitCR. Garbage collection will come in and do the final sweep of the blob.

        :param project_id: The non-human readable project ID used internally to identify projects.
        :param container: The name of the docker container a user wants to push up, ie, nginx, vllm, etc
        :return:

        Args:
            project_id: The non-human readable project ID used internally to identify projects.
            container: The name of the container repository to delete.

        Returns:
            V1DeleteLitRepositoryResponse: The deletion response from the server.

        Raises:
            ValueError: If the container cannot be deleted.
        """
        try:
            return self._client.lit_registry_service_delete_lit_repository(project_id, container)
        except Exception as e:
            raise ValueError(f"Could not delete container {container} from project {project_id}: {e!s}") from e

    def delete_container_by_digest(self, project_id: str, container: str, digest: str) -> None:
        """Deletes a container with a specific digest from LitCR.

        :param project_id: The non-human readable project ID used internally to identify projects.
        :param container: The name of the docker container a user wants to push up, ie, nginx, vllm, etc
        :param digest: The hash digest of the container to delete

        Args:
            project_id: The non-human readable project ID used internally to identify projects.
            container: The name of the container repository.
            digest: The content-addressable digest of the image to delete.

        Raises:
            ValueError: If the digest cannot be deleted.
        """
        try:
            self._client.lit_registry_service_delete_lit_registry_repository_image_artifact_version_by_digest(
                project_id, container, digest
            )
        except Exception as e:
            raise ValueError(
                f"Could not delete digest {digest} of container {container} from project {project_id}: {e!s}"
            ) from e

    def get_container_url(
        self, repository: str, tag: str, teamspace: Teamspace, cloud_account: Optional[str] = None
    ) -> str:
        """Docker container will be pushed to the URL returned from this function.

        Args:
            repository: The local image name (e.g. ``nginx`` or ``org/vllm``).
            tag: The image tag.
            teamspace: The teamspace the container will be stored in.
            cloud_account: Optional BYOC cluster ID; uses Lightning SaaS storage if ``None``.

        Returns:
            str: The full registry URL to push the tagged image to.
        """
        registry_url = _get_registry_url()
        container_basename = repository.split("/")[-1]
        return (
            f"{registry_url}/lit-container{f'-{cloud_account}' if cloud_account is not None else ''}/"
            f"{teamspace.owner.name}/{teamspace.name}/{container_basename}"
        )

    @retry_on_lcr_auth_failure
    def upload_container(
        self,
        container: str,
        teamspace: Teamspace,
        tag: str,
        cloud_account: Optional[str],
        platform: Optional[str],
        return_final_dict: bool = False,
    ) -> Generator[dict, None, None]:
        """Upload container will push the container to LitCR.

        It uses docker push API to interact with docker daemon which will then push the container to a storage
        location defined by teamspace + cloud_account. Will retry pushes if not authenticated or if push errors happen

        :param container: The name of the docker container a user wants to push up, ie, nginx, vllm, etc
        :param teamspace: The teamspace he container is going to appear in. This is <OWNER_ID>/<TEAMSPACE_NAME>
        :param tag: The container tag, default will latest.
        :param cloud_account: If empty will be pushed to Lightning SaaS storage. Otherwise, this will be cluster_id.
            Named cloud-account in the CLI options.
        :param platform: If empty will be linux/amd64. This is important because our entire deployment infra runs on
            linux/amd64. Will show user a warning otherwise.
        :return: Generator[dict, None, dict]

        Args:
            container: The local image name to push (e.g. ``nginx``, ``vllm``).
            teamspace: The teamspace the container will appear in.
            tag: The image tag to push.
            cloud_account: BYOC cluster ID, or empty string for Lightning SaaS storage.
            platform: Target platform (e.g. ``linux/amd64``).
            return_final_dict: When ``True``, yield a final summary dict with the container URL.

        Returns:
            Generator[dict, None, Dict]: Progress/status dicts from the Docker push, optionally followed by a
            summary dict when ``return_final_dict`` is ``True``.

        Raises:
            ValueError: If the container image cannot be found or tagged.
            DockerPushError: If the push fails after all retries.
        """
        try:
            self._docker_client.images.get(f"{container}:{tag}")
        except docker.errors.ImageNotFound:
            try:
                self._docker_client.images.pull(repository=container, tag=tag, platform=platform)
                self._docker_client.images.get(f"{container}:{tag}")
            except docker.errors.ImageNotFound as e:
                raise ValueError(f"Container {container}:{tag} does not exist") from e
            except docker.errors.APIError as e:
                raise ValueError(f"Could not pull container {container}") from e
            except Exception as e:
                raise ValueError(f"Unable to upload {container}:{tag}") from e

        repository = self.get_container_url(container, tag, teamspace, cloud_account)
        tagged = self._docker_client.api.tag(f"{container}:{tag}", repository, tag)
        if not tagged:
            raise ValueError(f"Could not tag container {container}:{tag} with {repository}:{tag}")
        yield from self._push_with_retry(repository, tag=tag)

        if return_final_dict:
            container_basename = repository.split("/")[-1]
            yield {
                "finish": True,
                "url": f"{LIGHTNING_CLOUD_URL}/{teamspace.owner.name}/{teamspace.name}/containers/"
                f"{container_basename}?section=tags"
                f"{f'?clusterId={cloud_account}' if cloud_account is not None else ''}",
                "repository": repository,
            }

    def _push_with_retry(self, repository: str, tag: str, max_retries: int = 3) -> Iterator[Dict[str, Any]]:
        """Push an image to a registry repository, retrying on auth or timeout errors up to ``max_retries`` times.

        Args:
            repository: The full registry repository URL to push to.
            tag: The image tag to push.
            max_retries: Maximum number of push attempts before raising.

        Returns:
            Iterator[Dict[str, Any]]: Progress/status dicts streamed from the Docker push API.

        Raises:
            DockerPushError: If the push fails after all retries or encounters a non-recoverable error.
        """

        def is_auth_error(error_msg: str) -> bool:
            auth_errors = ["unauthorized", "authentication required", "unauth"]
            return any(err in error_msg.lower() for err in auth_errors)

        def is_timeout_error(error_msg: str) -> bool:
            timeout_errors = ["proxyconnect tcp", "i/o timeout"]
            return any(err in error_msg.lower() for err in timeout_errors)

        for attempt in range(max_retries):
            try:
                if attempt > 0:
                    # This is important, if we don't set reauth here then we just keep using the
                    # same authentication context that we know just failed.
                    self.authenticate(reauth=True)
                    time.sleep(2)

                lines = self._docker_client.api.push(
                    repository, tag=tag, stream=True, decode=True, auth_config=self._docker_auth_config
                )
                for line in lines:
                    if isinstance(line, dict) and "error" in line:
                        error = line["error"]
                        if is_auth_error(error) or is_timeout_error(error):
                            if attempt < max_retries - 1:
                                break
                            raise DockerPushError(f"Max retries reached while pushing: {error}")
                        raise DockerPushError(f"Push error: {error}")
                    yield line
                else:
                    return

            except docker.errors.APIError as e:
                if (is_auth_error(str(e)) or is_timeout_error(str(e))) and attempt < max_retries - 1:
                    continue
                raise DockerPushError("Pushing the container failed") from e

        raise DockerPushError("Max push retries reached")

    @retry_on_lcr_auth_failure
    def download_container(
        self, container: str, teamspace: Teamspace, tag: str, cloud_account: Optional[str] = None
    ) -> bool:
        """Will download container from LitCR. Optionally from a BYOC cluster.

        :param container: The name of the container to download
        :param teamspace: The teamspace containing the container
        :param tag: The tag of the container to download
        :return: Generator yielding download status

        Args:
            container: The name of the container to download.
            teamspace: The teamspace containing the container.
            tag: The image tag to download.
            cloud_account: Optional BYOC cluster ID; uses Lightning SaaS storage if ``None``.

        Returns:
            Whether the downloaded image was tagged successfully.

        Raises:
            LCRAuthFailedError: If authentication with the registry fails.
            ValueError: If the container cannot be pulled.
        """
        registry_url = _get_registry_url()
        repository = (
            f"{registry_url}/lit-container{f'-{cloud_account}' if cloud_account is not None else ''}/"
            f"{teamspace.owner.name}/{teamspace.name}/{container}"
        )
        try:
            self._docker_client.images.pull(repository, tag=tag, auth_config=self._docker_auth_config)
        except requests.exceptions.HTTPError as e:
            if "unauthorized" in e.response.text:
                raise LCRAuthFailedError() from e
        except docker.errors.APIError as e:
            raise ValueError(f"Could not pull container {container} from {repository}:{tag}") from e
        return self._docker_client.api.tag(repository, container, tag)
