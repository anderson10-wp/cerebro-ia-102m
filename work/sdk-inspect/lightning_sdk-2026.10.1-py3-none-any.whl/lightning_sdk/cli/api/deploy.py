"""API deploy command."""

from typing import Any

import rich_click as click

from lightning_sdk.cli.legacy.deploy.serve import api_impl
from lightning_sdk.cli.legacy.upload import resolve_upload_recovery
from lightning_sdk.cli.utils.logging import LightningCommand
from lightning_sdk.cli.utils.teamspace_option import teamspace_option


@click.command("deploy", cls=LightningCommand)
@click.argument("script_path")
@click.option("--easy", is_flag=True, default=False, help="Generate a client for the model")
@click.option(
    "--cloud",
    is_flag=False,
    flag_value="",
    type=str,
    help="Run the model on cloud, optionally selecting a cloud provider or cloud account.",
)
@click.option("--name", default=None, help="Name of the deployed API (e.g., 'classification-api', 'Llama-api')")
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    default=False,
    help="Confirm the generated Dockerfile without prompting.",
)
@click.option("--machine", default="CPU", help="Machine type to deploy the API on. Defaults to CPU.")
@click.option(
    "--devbox",
    default=None,
    help="Machine type to build the API on. Setting this argument will open the server in a Studio.",
)
@click.option(
    "--interruptible", is_flag=True, default=False, help="Whether the machine should be interruptible (spot) or not."
)
@teamspace_option
@click.option("--port", default=None, type=int, help="The port to expose the API on.")
@click.option("--min_replica", "--min-replica", default=None, type=int, help="Number of replicas to start with.")
@click.option("--max_replica", "--max-replica", default=None, type=int, help="Number of replicas to scale up to.")
@click.option("--replicas", default=None, type=int, help="Deployment will start with this many replicas.")
@click.option(
    "--no_credentials",
    "--no-credentials",
    is_flag=True,
    default=False,
    help="Whether to include credentials in the deployment.",
)
@click.option("--resume", is_flag=True, help="Resume an incomplete upload.")
@click.option("--restart", is_flag=True, help="Restart an incomplete upload.")
def deploy_api(**kwargs: Any) -> None:
    """Deploy a LitServe model script."""
    kwargs["recovery"] = resolve_upload_recovery(
        resume=kwargs.pop("resume"),
        restart=kwargs.pop("restart"),
    )
    kwargs["include_credentials"] = not kwargs.pop("no_credentials")
    api_impl(**kwargs)
