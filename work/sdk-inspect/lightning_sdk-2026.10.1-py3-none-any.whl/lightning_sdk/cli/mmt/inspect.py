"""MMT inspect command."""

from typing import Optional

import rich_click as click

from lightning_sdk.cli.utils.json_output import echo_json
from lightning_sdk.cli.utils.logging import LightningCommand
from lightning_sdk.cli.utils.resource_resolution import resolve_mmt, resolve_teamspace


@click.command("inspect", cls=LightningCommand)
@click.option("--name", default=None, help="The multi-machine job name. Required.")
@click.option(
    "--teamspace",
    default=None,
    help=(
        "the name of the teamspace the job lives in. "
        "Should be specified as {teamspace_owner}/{teamspace_name} (e.g my-org/my-teamspace). "
        "If not specified, uses the configured default teamspace."
    ),
)
@click.option("--json", "as_json", is_flag=True, default=False, help="Output as JSON (inspect always emits JSON).")
def inspect_mmt(name: Optional[str] = None, teamspace: Optional[str] = None, as_json: bool = False) -> None:
    """Inspect a multi-machine job for further details as JSON."""
    resolved_teamspace = resolve_teamspace(teamspace)
    mmt = resolve_mmt(name, resolved_teamspace)
    echo_json(mmt.dict())
