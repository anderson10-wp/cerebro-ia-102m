"""Hidden CLI aliases for deprecated verb-first commands and plural nouns."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Any, Mapping, cast

import click

from lightning_sdk.cli.utils.logging import LightningGroup


def _format_redirect_message(old_command: str, replacement: str) -> str:
    return f"Use `{replacement}` instead of `{old_command}`."


def _format_deprecation_warning(old_command: str, replacement: str) -> str:
    return f"Deprecation warning: {_format_redirect_message(old_command, replacement)}"


def _echo_deprecation_warning(old_command: str, replacement: str) -> None:
    click.secho(_format_deprecation_warning(old_command, replacement), fg="yellow", err=True)


class DeprecatedForwardCommand(click.Command):
    """A hidden deprecated command alias that forwards to the replacement command."""

    def __init__(self, *args: Any, replacement: str, target_command: click.Command, **kwargs: Any) -> None:
        kwargs.setdefault("hidden", True)
        kwargs.setdefault("help", target_command.help)
        kwargs.setdefault("short_help", target_command.short_help)
        kwargs.setdefault("epilog", target_command.epilog)
        kwargs.setdefault("params", target_command.params)
        kwargs.setdefault("callback", target_command.callback)
        kwargs.setdefault("context_settings", target_command.context_settings)
        super().__init__(*args, **kwargs)
        self.replacement = replacement
        self.target_command = target_command

    def get_help(self, ctx: click.Context) -> str:
        return f"{_format_deprecation_warning(ctx.command_path, self.replacement)}\n\n{super().get_help(ctx)}"

    def invoke(self, ctx: click.Context) -> object:
        _echo_deprecation_warning(ctx.command_path, self.replacement)
        return super().invoke(ctx)


class LegacyForwardGroup(click.Group):
    """A hidden deprecated group that forwards verb-first commands to noun-first commands."""

    def __init__(
        self,
        *args: Any,
        replacements: Mapping[str, tuple[str, click.Command]],
        **kwargs: Any,
    ) -> None:
        kwargs.setdefault("hidden", True)
        kwargs.setdefault("add_help_option", False)
        super().__init__(*args, **kwargs)
        self.replacements = dict(replacements)

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if not args or args[0] in {"--help", "-h"}:
            replacements = "\n".join(
                f"  {old} -> {new}" for old, (new, _) in sorted(self.replacements.items(), key=lambda item: item[0])
            )
            raise click.ClickException(f"`{ctx.command_path}` has moved to noun-first commands:\n{replacements}")
        return super().parse_args(ctx, args)

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        replacement = self.replacements.get(cmd_name)
        if replacement is None:
            return None

        target_path, target_command = replacement
        return DeprecatedForwardCommand(name=cmd_name, replacement=target_path, target_command=target_command)

    def list_commands(self, ctx: click.Context) -> list[str]:
        return sorted(self.replacements)


def build_legacy_forward_group(name: str, replacements: Mapping[str, tuple[str, click.Command]]) -> LegacyForwardGroup:
    return LegacyForwardGroup(name=name, replacements=replacements)


def build_legacy_forward_command(
    name: str, replacement: str, target_command: click.Command
) -> DeprecatedForwardCommand:
    return DeprecatedForwardCommand(name=name, replacement=replacement, target_command=target_command)


class HiddenAliasGroup(LightningGroup):
    """A hidden plural alias that forwards to another noun-first group."""

    def __init__(self, *args: Any, target_group: click.Group, **kwargs: Any) -> None:
        kwargs.setdefault("hidden", True)
        kwargs.setdefault("help", target_group.help)
        super().__init__(*args, **kwargs)
        self.target_group = target_group

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        return self.target_group.get_command(ctx, cmd_name)

    def list_commands(self, ctx: click.Context) -> list[str]:
        return self.target_group.list_commands(ctx)


class DeprecatedGroup(LightningGroup):
    """A hidden group whose subcommands show deprecation warnings pointing to a replacement."""

    def __init__(
        self,
        *args: Any,
        replacement: str,
        replacement_group: click.Group | None = None,
        **kwargs: Any,
    ) -> None:
        kwargs.setdefault("hidden", True)
        super().__init__(*args, **kwargs)
        self._replacement = replacement
        self._replacement_group = replacement_group

    def get_help(self, ctx: click.Context) -> str:
        return f"{_format_deprecation_warning(ctx.command_path, self._replacement)}\n\n{super().get_help(ctx)}"

    def add_command(
        self,
        cmd: click.Command,
        name: str | None = None,
        aliases: Iterable[str] | None = None,
        panel: str | None = None,
    ) -> None:
        cmd_name = name or cmd.name
        dynamic_cmd = cast(Any, cmd)
        dynamic_cmd.invoke = self._make_deprecated_invoke(cmd.invoke, cmd_name)
        dynamic_cmd.get_help = self._make_deprecated_get_help(cmd.get_help, cmd_name)
        super().add_command(cmd, name, aliases=aliases, panel=panel)

    def _replacement_for(self, cmd_name: str | None) -> str:
        # Resolved lazily: the replacement group may gain its commands after this group is built.
        if self._replacement_group is None or cmd_name not in self._replacement_group.commands:
            return self._replacement
        return f"{self._replacement} {cmd_name}"

    def _make_deprecated_invoke(
        self, original_invoke: Callable[[click.Context], object], cmd_name: str | None
    ) -> Callable[[click.Context], object]:
        def _deprecated_invoke(ctx: click.Context) -> object:
            _echo_deprecation_warning(ctx.command_path, self._replacement_for(cmd_name))
            return original_invoke(ctx)

        return _deprecated_invoke

    def _make_deprecated_get_help(
        self, original_get_help: Callable[[click.Context], str], cmd_name: str | None
    ) -> Callable[[click.Context], str]:
        def _deprecated_get_help(ctx: click.Context) -> str:
            warning = _format_deprecation_warning(ctx.command_path, self._replacement_for(cmd_name))
            return f"{warning}\n\n" + original_get_help(ctx)

        return _deprecated_get_help


def build_hidden_alias_group(name: str, target_group: click.Group) -> HiddenAliasGroup:
    return HiddenAliasGroup(name=name, target_group=target_group)


def mark_deprecated_command(cmd: click.Command, replacement: str, detail: str | None = None) -> click.Command:
    """Mark a still-functional command as deprecated in favor of ``replacement``.

    Unlike :class:`DeprecatedForwardCommand`, the command keeps its own behavior; a
    warning is shown on every invocation and prepended to its help text. ``detail``
    is appended to the warning — use it when switching commands takes more than a
    rename (e.g. a different URL format).
    """
    dynamic_cmd = cast(Any, cmd)
    if getattr(dynamic_cmd, "_lightning_deprecation_wrapped", False):
        return cmd

    original_invoke = cmd.invoke
    original_get_help = cmd.get_help

    def _warning(ctx: click.Context) -> str:
        message = _format_deprecation_warning(ctx.command_path, replacement)
        return f"{message} {detail}" if detail else message

    def _deprecated_invoke(ctx: click.Context) -> object:
        click.secho(_warning(ctx), fg="yellow", err=True)
        return original_invoke(ctx)

    def _deprecated_get_help(ctx: click.Context) -> str:
        return f"{_warning(ctx)}\n\n{original_get_help(ctx)}"

    dynamic_cmd.invoke = _deprecated_invoke
    dynamic_cmd.get_help = _deprecated_get_help
    dynamic_cmd._lightning_deprecation_wrapped = True
    return cmd
